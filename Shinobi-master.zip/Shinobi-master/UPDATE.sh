git reset --hard
git pull
npm install
chmod +x INSTALL/shinobi
# npm audit fix --force
# pm2 restart camera
# pm2 restart cron
