$(window).resize(function(){
    $('.stream-element').attr('width',$('body').width())
    $('.stream-element').attr('height',$('body').height())
})
