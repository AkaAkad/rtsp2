# How do I make this Icon Set?

Go to http://www.favicomatic.com/ , upload your image and let it do the magic.

Remember! if you use favicomatic.com and it helps you, please consider donating to them.

- Moe Alam