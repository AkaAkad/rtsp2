## Contributing license
By contributing to this repository, you agree your contributions to be bound by the [SHINOBI OPEN SOURCE SOFTWARE LICENSE AGREEMENT
](LICENSE.md)

## Suggestions
For suggestions to this project, please refer to the [README](README.md)

## Development
For contributing to the repository, please refer to [DEVELOPMENT.md](DEVELOPMENT.md)
